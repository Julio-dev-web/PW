function changeP(){
	document.getElementById('p1').innerHTML = "Este e' um paragrafo modificado por javascript";
	document.getElementById('p1').style.color="red";
	document.getElementById('p1').style.fontSize="24px";
}